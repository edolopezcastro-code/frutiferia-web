/* eslint-disable no-useless-constructor */
/* global DeferredMedia */

if (!customElements.get('product-model')) {
  class ProductModel extends DeferredMedia {
    constructor() {
      super();
    }

    handleMouseMove(evt) {
      if (!this.modelViewer.classList.contains('shopify-model-viewer-ui__disabled')) {
        evt.preventDefault();
        evt.stopPropagation();
      }
    }

    loadContent() {
      super.loadContent();

      Shopify.loadFeatures([
        {
          name: 'model-viewer-ui',
          version: '1.0',
          onLoad: this.setupModelViewerUI.bind(this)
        }
      ]);
    }

    setupModelViewerUI(errors) {
      if (errors) return;

      this.modelViewer = this.querySelector('model-viewer');
      this.modelViewerUI = new Shopify.ModelViewerUI(this.modelViewer);
      this.addEventListener('mousemove', this.handleMouseMove.bind(this));
    }
  }

  customElements.define('product-model', ProductModel);
}

window.ProductModel = {
  loadShopifyXR() {
    Shopify.loadFeatures([
      {
        name: 'shopify-xr',
        version: '1.0',
        onLoad: this.setupShopifyXR.bind(this)
      }
    ]);
  },

  setupShopifyXR(errors) {
    if (errors) return;

    if (!window.ShopifyXR) {
      document.addEventListener('shopify_xr_initialized', () => this.setupShopifyXR());
      return;
    }

    document.querySelectorAll('[id^="product-json-"]').forEach((modelJSON) => {
      window.ShopifyXR.addModels(JSON.parse(modelJSON.textContent));
      modelJSON.remove();
    });

    window.ShopifyXR.setupXRElements();
  }
};

window.addEventListener('DOMContentLoaded', () => {
  if (window.ProductModel) window.ProductModel.loadShopifyXR();
});
